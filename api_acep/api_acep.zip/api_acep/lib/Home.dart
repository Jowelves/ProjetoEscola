import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  _recuperarCep() async {
   //um tipo//=> String url = "https://viacep.com.br/ws/01311300/json/";
  String cep = "01311300";
  String url= "https://viacep.com.br/ws/${cep}/json/";
  http.Response response;

  response = await http.get(url);

  print("resposta: " + response.body);
  print("resposta: " + response.statusCode.toString());

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Consumo de serviço API web"),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            RaisedButton(
              child: Text("Clique aqui"),
              onPressed: _recuperarCep,
            )
          ],
        ),
      ),
    );
  }
}
